This folder contains a complete ORCHESTRA system without the orchestra2026.jar file 
and a renamed batch file to start up orchestra.

These two files cannot send by e-mail because of security reasons.

The .jar file can be downloaded from :

www.meeussen.nl/orchestra/orchestra2026.jar

The batch file can be created by renaming: 

runorchestra.renametobat

To:

runorchestra.bat

or creating your own batch file with the following startup command

java -cp orchestra2026.jar orchestra2.composer


It is preferable to start up ORCHESTRA via the batch file as this will also open a command line window 
which will show any java virtual machine error messages.  
